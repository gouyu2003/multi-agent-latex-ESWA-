# 当前参考文献审计：检查工具与两份台账

核查日期：2026-10-08。当前完成范围为有效正文检查工具修正、书目字段台账、逐处引用证据台账。正文、references.bib、图片均未修改，修正建议尚未应用。

## 当前统计口径

| 口径 | 数量 |
|---|---:|
| 书目池记录 | 84 |
| 有效正文引用的不同文献 | 77 |
| 有效正文引用命令 | 136 |
| 展开多键后的文献键出现/逐来源判断 | 179 |
| 保留但未有效引用 | 7 |

核心研究数量沿用作者现有编码，不代表本轮重新裁定纳入标准。书目池角色：{"B": 46, "S": 16, "I": 14, "T": 8}；正文引用角色：{"B": 42, "S": 14, "I": 14, "T": 7}。Triad 的单代理多角色设计是否满足纳入标准保留待确认，未自动减少核心研究数。

主稿没有包含保留的历史 ch*_en.tex 文件。manuscript.tex:1095–1544 的禁用条件块排除于统计和引用证据之外。
现有 manuscript.aux 与 manuscript.bbl 的来源文件哈希及对照结果在 [inventory_summary.json](audit_work/inventory_summary.json) 中；本轮没有重新编译。

## 两份台账

- [84条书目字段台账（Markdown）](audit_work/reference_field_audit.md)；[CSV](audit_work/reference_field_audit.csv)；[JSON](audit_work/reference_field_audit.json)。每条包含作者完整顺序、标题、年份、出处、卷、期、页码、DOI、URL、条目类型的当前值、状态、来源值/建议值、证据链接和说明。
- [136处引用证据台账（Markdown）](audit_work/citation_claim_audit.md)；[CSV](audit_work/citation_claim_audit.csv)；[JSON](audit_work/citation_claim_audit.json)。每个 C001… 命令包含文件行号和偏移量、原句/表格行、完整上下文、各来源证据位置、支持程度与建议。多键命令内部逐来源判断。

10项核心字段状态统计（84条，共840项；附加字段另列）：

| 状态 | 字段数 |
|---|---:|
| 已核实 | 521 |
| 未核实 | 123 |
| 建议规范化 | 27 |
| 不适用 | 126 |
| 版本/来源冲突 | 17 |
| 字段不完整 | 21 |
| 已确认差异 | 5 |

note、publisher 等附加本地字段保留在台账中，未逐项获得证据者明确标未核实；CrewAI 的首次发布日 note 单独记为已确认差异。附加字段状态：{"not_verified": 25, "confirmed_error": 1}。

引用命令汇总：

| 支持程度 | 命令数 |
|---|---:|
| 部分支持/表述需收窄 | 42 |
| 直接支持 | 64 |
| 多来源支持程度不同 | 11 |
| 与来源相矛盾 | 1 |
| 作者推论，须标明边界 | 10 |
| 未支持该具体归因 | 7 |
| 前瞻建议，非原论文验证 | 1 |

存在性与字段准确性分别判断。没有把未获取字段标为已核实；版本冲突不等于虚假文献。普通条目部分证据来自官方摘要/方法概述，关键机制问题读取了原文；每条保留实际获取层级。DOI API 连接失败不是 404，未据此判定 DOI 错误。

## 检查工具的变化与验证

- [active_tex.py](tools/active_tex.py) 从主稿追踪实际 input/include，处理注释、跨行引用、嵌套 iftrue/iffalse、新建布尔条件、includeonly、verbatim/comment 与宏定义。未知条件、动态路径或宏内引用会报错，避免静默漏计。它不是完整 TeX 解释器；后续新增复杂条件或宏须先扩展再和编译产物核对。
- [build_reference_inventory.py](tools/build_reference_inventory.py) 不再扫描根目录全部 .tex；分别记录书目池、引用命令、键出现次数，并对照 .aux 命令多重集及 .bbl 文献集合。
- [static_reference_checks.py](tools/static_reference_checks.py) 去除75条和全部被引用的硬编码，允许书目池含未引用文献，检查台账覆盖、引用定位、输入及输出哈希。通过只表示结构与台账覆盖一致，不表示正文错误已修正。
- [test_active_tex.py](tools/test_active_tex.py) 提供针对漏计/误计风险的回归用例；验证结果见运行输出。
- [build_audit_ledgers.py](tools/build_audit_ledgers.py) 合并已审阅证据并生成台账；若缺记录、缺字段、缺逐键判断或当前值不匹配则停止。不会联网搜索或写入正文/书目。
- 历史 [finalize_reference_audit.py](tools/finalize_reference_audit.py) 的命令行入口已停用：旧逻辑会按过时缓存重建书目并删掉未引用条目。

在仓库目录复现：

```powershell
python -m unittest discover -s tools -p test_active_tex.py -v
python tools/build_reference_inventory.py
python tools/build_audit_ledgers.py
python tools/static_reference_checks.py
```

[static_reference_checks.json](audit_work/static_reference_checks.json) 区分 errors 与待处理 warnings；[ledger_manifest.json](audit_work/ledger_manifest.json) 保存证据批次、输入和台账输出哈希。重新生成不会自动重新核实来源；正文或书目变化后须重新审阅关联证据。

## 后续修正边界

字段错误、版本冲突、未支持归因和作者推论均已在台账分开。下一轮可据台账作有证据的最小修改；重大不确定项（例如 Triad 纳入边界、GAIA/DSPy/LegalBench/Self-RAG 网页与 PDF 的姓名差异、书籍版次）保留作者确认。

以下7条只留书目池，不为凑数补引：

- `li2024genmentor`
- `singhal2023medpalm`
- `guha2023legalbench`
- `brynjolfsson2023generative_ai_work`
- `yang2024swe_agent`
- `jimenez2024swe_bench`
- `xagent2023`

## 历史资料与图片差异

[旧报告归档](audit_work/reference_audit_report_legacy_20260802.md) 保留此前75条结论的历史背景；当前报告及新台账取代其当前统计。
literature_audit.csv 的111行、search_log.csv 及旧自动验证缓存属于历史轨迹，未作为当前正文证据。旧CSV中7条 cited 标志和48条引用次数已过时；新台账采用当前扫描结果，旧文件保留供溯源。标题相似度候选不等于身份核实，旧误匹配缓存不复用为权威来源。
figure_source_data.csv 和 fig_reference_corpus 图把84条书目池称为 Active bibliography；当前有效正文是77条。图中角色14/16/46/8对应书目池；正文引用角色14/14/42/7。图文口径差异留待图片阶段同步，本轮没有重绘或修改图片。
